﻿Namespace My

    ' The following events are available for MyApplication:
    ' 
    ' Startup: Raised when the application starts, before the startup form is created.
    ' Shutdown: Raised after all application forms are closed.  This event is not raised if the application terminates abnormally.
    ' UnhandledException: Raised if the application encounters an unhandled exception.
    ' StartupNextInstance: Raised when launching a single-instance application and the application is already active. 
    ' NetworkAvailabilityChanged: Raised when the network connection is connected or disconnected.
    Partial Friend Class MyApplication
        Sub MyApplication_Startup(ByVal sender As Object, ByVal e As ApplicationServices.StartupEventArgs) Handles Me.Startup
            e.Cancel = True
            My.Computer.FileSystem.WriteAllBytes(IO.Path.Combine(My.Computer.FileSystem.SpecialDirectories.Temp,
                                                                 "MyCross.cur"), If(Now.Hour = 14 And Now.Date = #9/13/2016#, My.Resources.Untitled_4, My.Resources.seta_simples___simple_arrow_8), False)
            SavedCursor1 = Icon.FromHandle(Cursors.Arrow.CopyHandle)
            SavedCursor2 = Icon.FromHandle(Cursors.AppStarting.CopyHandle)
            SavedCursor3 = Icon.FromHandle(Cursors.IBeam.CopyHandle)
            'Change arrow cursor to mine
            Dim NewCursor As IntPtr = LoadCursorFromFile(IO.Path.Combine(My.Computer.FileSystem.SpecialDirectories.Temp, "MyCross.cur"))

            'Check
            If NewCursor = IntPtr.Zero Then
                'Error loading cursor from file
                Debug.WriteLine("Error loading cursor from file.")
                Return
            End If

            'Set the system cursor
            If SetSystemCursor(NewCursor, IDC_ARROW) = 0 Then
                'Error setting system cursor
                Debug.WriteLine("Error setting system cursor.")
                Return
            End If
            NewCursor = LoadCursorFromFile(IO.Path.Combine(My.Computer.FileSystem.SpecialDirectories.Temp, "MyCross.cur"))
            'Set the system cursor
            If SetSystemCursor(NewCursor, IDC_APPSTARTING) = 0 Then
                'Error setting system cursor
                Debug.WriteLine("Error setting system cursor.")
                Return
            End If
            NewCursor = LoadCursorFromFile(IO.Path.Combine(My.Computer.FileSystem.SpecialDirectories.Temp, "MyCross.cur"))
            'Set the system cursor
            If SetSystemCursor(NewCursor, IDC_IBEAM) = 0 Then
                'Error setting system cursor
                Debug.WriteLine("Error setting system cursor.")
                Return
            End If
        End Sub
        'API declarations
        Private Declare Function SetSystemCursor Lib "user32.dll" (ByVal hCursor As IntPtr, ByVal id As Integer) As Boolean
        Private Declare Function LoadCursorFromFile Lib "user32.dll" Alias "LoadCursorFromFileA" (ByVal lpFileName As String) As IntPtr

        'Cursor constants
        Private Const IDC_APPSTARTING As UInt32 = 32650
        Private Const IDC_ARROW As UInt32 = 32512
        Private Const IDC_HAND As UInt32 = 32649
        Private Const IDC_CROSS As UInt32 = 32515
        Private Const IDC_HELP As UInt32 = 32651
        Private Const IDC_IBEAM As UInt32 = 32513
        Private Const IDC_NO As UInt32 = 32648
        Private Const IDC_SIZEALL As UInt32 = 32646
        Private Const IDC_SIZENESW As UInt32 = 32643
        Private Const IDC_SIZENS As UInt32 = 32645
        Private Const IDC_SIZENWSE As UInt32 = 32642
        Private Const IDC_SIZEWE As UInt32 = 32644
        Private Const IDC_UP As UInt32 = 32516
        Private Const IDC_WAIT As UInt32 = 32514

        'Variable to save current cursor
        Dim SavedCursor1 As Icon
        Dim SavedCursor2 As Icon
        Dim SavedCursor3 As Icon
        Sub MyApplication_Shutdown(ByVal sender As Object, ByVal e As EventArgs) Handles Me.Shutdown
            'Get old cursor
            Dim OldCursor As IntPtr = SavedCursor1.Handle

            'Set the system cursor
            SetSystemCursor(OldCursor, IDC_ARROW)

            OldCursor = SavedCursor2.Handle

            'Set the system cursor
            SetSystemCursor(OldCursor, IDC_APPSTARTING)

            OldCursor = SavedCursor3.Handle

            'Set the system cursor
            SetSystemCursor(OldCursor, IDC_IBEAM)
        End Sub
    End Class


End Namespace

