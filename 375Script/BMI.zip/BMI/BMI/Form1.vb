﻿Public Class Form1

    Private Sub Button1_Click(sender As System.Object, e As System.EventArgs) Handles Button1.Click
        Dim BMI = Math.Round(NumericUpDown2.Value / NumericUpDown1.Value ^ 2, 2)
        Label4.Text = "BMI = " & BMI
        Select Case BMI
            Case Is < 18.5
                MsgBox("Underweight")
            Case 18.5 To 24
                MsgBox("Normal")
            Case 24 To 27
                MsgBox("Overweight")
            Case Else
                MsgBox("Obese")
        End Select
    End Sub
End Class
