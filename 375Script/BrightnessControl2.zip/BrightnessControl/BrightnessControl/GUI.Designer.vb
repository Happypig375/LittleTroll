﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class GUI
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.TrackBar1 = New System.Windows.Forms.TrackBar()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.ColorSel = New System.Windows.Forms.ColorDialog()
        Me.ColorButton = New System.Windows.Forms.Button()
        Me.ColorDisplay = New System.Windows.Forms.PictureBox()
        Me.ColorClr = New System.Windows.Forms.Button()
        Me.ColorRnd = New System.Windows.Forms.Button()
        CType(Me.TrackBar1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ColorDisplay, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'TrackBar1
        '
        Me.TrackBar1.LargeChange = 25
        Me.TrackBar1.Location = New System.Drawing.Point(37, 12)
        Me.TrackBar1.Maximum = 256
        Me.TrackBar1.Minimum = 1
        Me.TrackBar1.Name = "TrackBar1"
        Me.TrackBar1.Size = New System.Drawing.Size(506, 45)
        Me.TrackBar1.TabIndex = 0
        Me.TrackBar1.Value = 1
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(12, 21)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(25, 13)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "255"
        '
        'ColorButton
        '
        Me.ColorButton.Location = New System.Drawing.Point(43, 63)
        Me.ColorButton.Name = "ColorButton"
        Me.ColorButton.Size = New System.Drawing.Size(75, 23)
        Me.ColorButton.TabIndex = 2
        Me.ColorButton.Text = "Filter Colour"
        Me.ColorButton.UseVisualStyleBackColor = True
        '
        'ColorDisplay
        '
        Me.ColorDisplay.Location = New System.Drawing.Point(13, 63)
        Me.ColorDisplay.Name = "ColorDisplay"
        Me.ColorDisplay.Size = New System.Drawing.Size(24, 24)
        Me.ColorDisplay.TabIndex = 3
        Me.ColorDisplay.TabStop = False
        '
        'ColorClr
        '
        Me.ColorClr.Location = New System.Drawing.Point(124, 63)
        Me.ColorClr.Name = "ColorClr"
        Me.ColorClr.Size = New System.Drawing.Size(75, 23)
        Me.ColorClr.TabIndex = 4
        Me.ColorClr.Text = "Clear Filter"
        Me.ColorClr.UseVisualStyleBackColor = True
        '
        'ColorRnd
        '
        Me.ColorRnd.Location = New System.Drawing.Point(205, 63)
        Me.ColorRnd.Name = "ColorRnd"
        Me.ColorRnd.Size = New System.Drawing.Size(89, 23)
        Me.ColorRnd.TabIndex = 5
        Me.ColorRnd.Text = "Random Filter"
        Me.ColorRnd.UseVisualStyleBackColor = True
        '
        'GUI
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(555, 102)
        Me.Controls.Add(Me.ColorRnd)
        Me.Controls.Add(Me.ColorClr)
        Me.Controls.Add(Me.ColorDisplay)
        Me.Controls.Add(Me.ColorButton)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.TrackBar1)
        Me.Name = "GUI"
        Me.Text = "BrightnessControl"
        CType(Me.TrackBar1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ColorDisplay, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents TrackBar1 As System.Windows.Forms.TrackBar
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents ColorSel As System.Windows.Forms.ColorDialog
    Friend WithEvents ColorButton As System.Windows.Forms.Button
    Friend WithEvents ColorDisplay As System.Windows.Forms.PictureBox
    Friend WithEvents ColorClr As System.Windows.Forms.Button
    Friend WithEvents ColorRnd As System.Windows.Forms.Button

End Class
