﻿Namespace My

    ' The following events are available for MyApplication:
    ' 
    ' Startup: Raised when the application starts, before the startup form is created.
    ' Shutdown: Raised after all application forms are closed.  This event is not raised if the application terminates abnormally.
    ' UnhandledException: Raised if the application encounters an unhandled exception.
    ' StartupNextInstance: Raised when launching a single-instance application and the application is already active. 
    ' NetworkAvailabilityChanged: Raised when the network connection is connected or disconnected.
    Partial Friend Class MyApplication
        Dim Restart As Boolean = False
        Event Sync(ByVal Proc As Process)
        Sub MyApplication_Startup(ByVal sender As Object, ByVal e As Microsoft.VisualBasic.ApplicationServices.StartupEventArgs) Handles Me.Startup
#If False Then
            Dim Str As String
            For Each Process As Process In System.Diagnostics.Process.GetProcesses
                If Process.ProcessName = "wmplayer" Then Str &= Process.MainWindowHandle.ToString & " abc|" & Process.MainWindowTitle & "|"
            Next
            MsgBox(Str)
            End
            Const WMLoc As String = "C:\Program Files\Windows Media Player\wmplayer.exe"
            Kill()
#End If
Restart:    Restart = False
            Const WAVLoc As String = "C:\Users\CSW\Downloads\Binaries\Binaries\"
            Const INTRO As String = "JESUS CHRIST INTRO.wav"
            Const CONTENT As String = "JESUS CHRIST CONTENT.wav"
            Const OUTRO As String = "JESUS CHRIST OUTRO.wav"
            RaiseEvent Sync(Kill())
            My.Computer.Audio.Play(WAVLoc & INTRO, AudioPlayMode.WaitToComplete)
            If Restart Then GoTo Restart
            For i = 1 To 2
                My.Computer.Audio.Play(WAVLoc & CONTENT, AudioPlayMode.WaitToComplete)
                If Restart Then GoTo Restart
            Next
            My.Computer.Audio.Play(WAVLoc & OUTRO, AudioPlayMode.WaitToComplete)
            GoTo Restart
        End Sub
        Function Kill() As Process
            Dim P As Boolean = False
            Do
                For Each Process As Process In System.Diagnostics.Process.GetProcesses
                    If Process.ProcessName = "wmplayer" And Process.MainWindowTitle = "Windows Media Player" Then
                        Process.CloseMainWindow()
                        P = True
                        Kill = Process
                    End If
                Next
            Loop Until P
        End Function
        Sub SyncIt(ByVal Proc As Process) Handles Me.Sync
            Exit Sub
            Do
            Loop Until Proc.MainWindowTitle = ""
            My.Computer.Audio.Stop()
            Restart = True
        End Sub
    End Class
End Namespace

