﻿Public Class Form1
    Dim Stop1, Stop2, Stop3 As Boolean

    Dim _Random As New Random()
    Function Random() As Integer
        Return _Random.Next(10)
    End Function
    Function RandomColor() As Color
        Return Color.FromArgb(&HFF000000 + _Random.Next(&HFFFFFF))
    End Function

    Sub CheckWin()
        If Stop1 AndAlso Stop2 AndAlso Stop3 Then
            If Label1.Text = Label2.Text AndAlso Label2.Text = Label3.Text Then
                MsgBox("You win!")
            Else
                MsgBox("You lose!")
            End If
        End If
    End Sub
    Private Sub Timer1_Tick(sender As System.Object, e As System.EventArgs) Handles Timer1.Tick
        If Not Stop1 Then Label2.Text = Random()
        If Not Stop2 Then Label1.Text = Random()
        If Not Stop3 Then Label3.Text = Random()
    End Sub

    Private Sub Button1_Click(sender As System.Object, e As System.EventArgs) Handles Button1.Click
        Stop2 = True
        Button1.Enabled = False
        CheckWin()
    End Sub
    Private Sub Button3_Click(sender As System.Object, e As System.EventArgs) Handles Button3.Click
        Stop1 = True
        Button3.Enabled = False
        CheckWin()
    End Sub
    Private Sub Button4_Click(sender As System.Object, e As System.EventArgs) Handles Button4.Click
        Stop3 = True
        Button4.Enabled = False
        CheckWin()
    End Sub

    Private Sub Button2_Click(sender As System.Object, e As System.EventArgs) Handles Button2.Click
        Timer1.Enabled = True
        Button1.Enabled = True
        Button3.Enabled = True
        Button4.Enabled = True
        Stop1 = False
        Stop2 = False
        Stop3 = False
        Timer1_Tick(Nothing, EventArgs.Empty)
    End Sub

    Private Sub Form1_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        Label1.BackColor = RandomColor()
        Label2.BackColor = RandomColor()
        Label3.BackColor = RandomColor()
    End Sub

    Private Sub HScrollBar1_ValueChanged(sender As System.Object, e As System.EventArgs) Handles HScrollBar1.ValueChanged
        Timer1.Interval = 1000 - HScrollBar1.Value * 10
    End Sub
End Class
