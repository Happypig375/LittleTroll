﻿Public Class Form1

    Dim Random As New Random()
    ReadOnly Property RandomTicks As Byte
        Get
            Return Random.Next(5, 200)
        End Get
    End Property
    ReadOnly Property RandomColor As Color
        Get
            Dim Buffer(2) As Byte
            Random.NextBytes(Buffer)
            Return Color.FromArgb(Buffer(0), Buffer(1), Buffer(2))
        End Get
    End Property
    Dim A, B, C As Byte
    Private Sub Button1_Click(sender As System.Object, e As System.EventArgs) Handles Button1.Click
        A = RandomTicks
        B = RandomTicks
        C = RandomTicks
    End Sub

    Private Sub Timer1_Tick(sender As System.Object, e As System.EventArgs) Handles Timer1.Tick
        If A > 0 Then
            A -= 1
            Label1.Text = Random.Next(1, 7)
        End If
        If B > 0 Then
            B -= 1
            Label2.Text = Chr(Asc("A"c) + Random.Next(0, 4))
        End If
        If C > 0 Then
            C -= 1
            Label3.Text = Random.Next(1, 37).ToString("00")
        End If
    End Sub

    Private Sub Form1_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        Label1.BackColor = RandomColor
        Label2.BackColor = RandomColor
        Label3.BackColor = RandomColor
    End Sub
End Class
