﻿Public Class Form1
    Dim Ticks As Long = 0
    Dim Down As Boolean = False
    Private Sub Timer1_Tick(sender As System.Object, e As System.EventArgs) Handles Timer1.Tick
        If Not Down Then
            Ticks += 100000
        ElseIf Ticks > 0 Then
            Ticks -= 100000
        End If
        Refresh()
    End Sub

    Private Sub Button1_Click(sender As System.Object, e As System.EventArgs) Handles Button1.Click
        Timer1.Enabled = True
        UpDownChanged()
        Refresh()
    End Sub

    Private Sub Button2_Click(sender As System.Object, e As System.EventArgs) Handles Button2.Click
        Timer1.Enabled = False
        Refresh()
    End Sub

    Private Sub Button3_Click(sender As System.Object, e As System.EventArgs) Handles Button3.Click
        Ticks = 0
        Refresh()
    End Sub

    Public Overrides Sub Refresh()
        MyBase.Refresh()
        Label1.Text = New TimeSpan(Ticks).ToString("d\.hh\:mm\:ss\.ff").PadLeft(15)
    End Sub

    Private Sub TrackBar1_ValueChanged(sender As System.Object, e As System.EventArgs) Handles TrackBar1.ValueChanged
        Down = Convert.ToBoolean(TrackBar1.Value)
    End Sub

    Private Sub UpDownChanged() Handles NumericUpDown1.ValueChanged, NumericUpDown2.ValueChanged,
        NumericUpDown3.ValueChanged, NumericUpDown4.ValueChanged, NumericUpDown5.ValueChanged
        If Down Then Ticks = New TimeSpan(
            NumericUpDown4.Value, NumericUpDown1.Value, NumericUpDown2.Value, NumericUpDown3.Value, NumericUpDown5.Value).Ticks
    End Sub
End Class
