﻿Public Class Calc
    'https://www.dropbox.com/s/9y99abczof4lu1d/EduE2.zip

    Private Sub Fract_Click(sender As System.Object, e As System.EventArgs) Handles Fract.Click
        Ratio.ThrowStackOverflow()
        Out.Text = New Ratio(Numerator.Value / Denominator.Value).ToString
    End Sub
End Class
