﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Calc
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Numerator = New System.Windows.Forms.NumericUpDown()
        Me.Denominator = New System.Windows.Forms.NumericUpDown()
        Me.Fract = New System.Windows.Forms.Button()
        Me.Out = New System.Windows.Forms.TextBox()
        CType(Me.Numerator, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Denominator, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Numerator
        '
        Me.Numerator.Location = New System.Drawing.Point(13, 13)
        Me.Numerator.Maximum = New Decimal(New Integer() {276447231, 23283, 0, 0})
        Me.Numerator.Minimum = New Decimal(New Integer() {1316134911, 2328, 0, -2147483648})
        Me.Numerator.Name = "Numerator"
        Me.Numerator.Size = New System.Drawing.Size(259, 20)
        Me.Numerator.TabIndex = 0
        '
        'Denominator
        '
        Me.Denominator.Location = New System.Drawing.Point(13, 40)
        Me.Denominator.Maximum = New Decimal(New Integer() {276447231, 23283, 0, 0})
        Me.Denominator.Minimum = New Decimal(New Integer() {1316134911, 2328, 0, -2147483648})
        Me.Denominator.Name = "Denominator"
        Me.Denominator.Size = New System.Drawing.Size(259, 20)
        Me.Denominator.TabIndex = 1
        '
        'Fract
        '
        Me.Fract.Location = New System.Drawing.Point(13, 67)
        Me.Fract.Name = "Fract"
        Me.Fract.Size = New System.Drawing.Size(259, 23)
        Me.Fract.TabIndex = 2
        Me.Fract.Text = "To Fraction"
        Me.Fract.UseVisualStyleBackColor = True
        '
        'Out
        '
        Me.Out.Location = New System.Drawing.Point(13, 97)
        Me.Out.Name = "Out"
        Me.Out.ReadOnly = True
        Me.Out.Size = New System.Drawing.Size(259, 20)
        Me.Out.TabIndex = 3
        '
        'Calc
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(284, 132)
        Me.Controls.Add(Me.Out)
        Me.Controls.Add(Me.Fract)
        Me.Controls.Add(Me.Denominator)
        Me.Controls.Add(Me.Numerator)
        Me.Name = "Calc"
        Me.Text = "RatioCalc"
        CType(Me.Numerator, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Denominator, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Numerator As System.Windows.Forms.NumericUpDown
    Friend WithEvents Denominator As System.Windows.Forms.NumericUpDown
    Friend WithEvents Fract As System.Windows.Forms.Button
    Friend WithEvents Out As System.Windows.Forms.TextBox

End Class
