﻿Imports System.Numerics
Imports System.Linq.Expressions
Imports System.Runtime.InteropServices

Public Class Ratio
    Public Property Numerator As New BigInteger(0)
    Public Property Denominator As New BigInteger(1)
    Sub New(Numerator As ValueType, Denominator As ValueType)
        Select Case Numerator.GetType
            Case GetType(Byte), GetType(SByte), GetType(Short), GetType(UShort), GetType(Integer),
                GetType(UInteger), GetType(Long), GetType(ULong), GetType(BigInteger)
                Me.Numerator = CType(Numerator, BigInteger)
        End Select
        Select Case Denominator.GetType
            Case GetType(Byte), GetType(SByte), GetType(Short), GetType(UShort), GetType(Integer),
                GetType(UInteger), GetType(Long), GetType(ULong), GetType(BigInteger)
                Me.Denominator = CType(Denominator, BigInteger)
        End Select
    End Sub
    Sub New(Number As ValueType)
        Select Case Number.GetType
            Case GetType(Byte), GetType(SByte), GetType(Short), GetType(UShort), GetType(Integer),
                GetType(UInteger), GetType(Long), GetType(ULong), GetType(BigInteger)
                Numerator = CType(Number, BigInteger)
            Case GetType(Single)
                Float2Fraction(CSng(Number), Me)
            Case GetType(Double)
                Float2Fraction(CDbl(Number), Me)
            Case GetType(Decimal)
                Float2Fraction(CDec(Number), Me)
            Case Else
                Throw New ArgumentException("Argument is not a valid number.", "Number")
        End Select
    End Sub
    Public Shared Sub Float2Fraction(Float As Single, <Out()> ByRef [Return] As Ratio)
        [Return] = GetFraction(Float).ToRatio
    End Sub
    Public Shared Sub Float2Fraction(Float As Double, <Out()> ByRef [Return] As Ratio)
        [Return] = GetFraction(Float).ToRatio
    End Sub
    Public Shared Sub Float2Fraction(Float As Decimal, <Out()> ByRef [Return] As Ratio)
        [Return] = GetFraction(Float).ToRatio
    End Sub
    Friend Structure MixedFraction(Of T As {IComparable, IComparable(Of T), IEquatable(Of T), IFormattable, Structure})
        Implements IComparable(Of MixedFraction(Of T))
        Public Property Numerator As T
        Public Property Denominator As T
        Public Property WholeNumber As T
        Public Property None As Boolean
        Public Function ToRatio() As Ratio
            If GetType(T) = GetType(Decimal) Then
                Return New Ratio(Convert.ChangeType(WholeNumber, GetType(Decimal)) *
                                 Convert.ChangeType(Denominator, GetType(Decimal)) +
                                 Convert.ChangeType(Numerator, GetType(Decimal)) /
                                 Convert.ChangeType(Denominator, GetType(Decimal)))

            Else
                Return New Ratio(Convert.ChangeType(WholeNumber, GetType(BigInteger)) *
                                 Convert.ChangeType(Denominator, GetType(BigInteger)) +
                                 Convert.ChangeType(Numerator, GetType(BigInteger)),
                                 Convert.ChangeType(Denominator, GetType(BigInteger)))
            End If
        End Function
        Public Overrides Function ToString() As String
            Return If(None, "None", If(WholeNumber = Convert.ChangeType(0, GetType(T)), "", WholeNumber.
                                       ToString("G", System.Globalization.CultureInfo.CurrentCulture) & " "c) &
                        Numerator.ToString("G", System.Globalization.CultureInfo.CurrentCulture) &
                       "/"c & Denominator.ToString("G", System.Globalization.CultureInfo.CurrentCulture))
        End Function
        Private Function CompareTo(Other As MixedFraction(Of T)) As Integer _
        Implements IComparable(Of RatioCalc.Ratio.MixedFraction(Of T)).CompareTo
            Throw New NotImplementedException("Nope")
        End Function
    End Structure
    Friend Shared Function GetFraction(ByVal Num As Single) As MixedFraction(Of Single)

        If Num = 0.0# Then
            GetFraction = New MixedFraction(Of Single) With {.None = True}
        Else
            Dim WholeNumber As Integer
            Dim DecimalNumber As Single
            Dim Numerator As Single
            Dim Denomenator As Single
            Dim a, b, t As Single

            WholeNumber = Fix(Num)
            DecimalNumber = Num - Fix(Num)
            Numerator = DecimalNumber * 10 ^ (Len(CStr(DecimalNumber)) - 2)
            Denomenator = 10 ^ (Len(CStr(DecimalNumber)) - 2)
            If Numerator = 0 Then
                GetFraction = New MixedFraction(Of Single) With {.WholeNumber = WholeNumber}
            Else
                a = Numerator
                b = Denomenator
                t = 0

                While b <> 0
                    t = b
                    b = a Mod b
                    a = t
                End While
                If WholeNumber = 0 Then
                    GetFraction = New MixedFraction(Of Single) With {.Numerator = Numerator / a,
                                                                   .Denominator = Denomenator / a}
                Else
                    GetFraction = New MixedFraction(Of Single) With {.WholeNumber = WholeNumber,
                                                                   .Numerator = Numerator / a,
                                                                   .Denominator = Denomenator / a}
                End If
            End If
        End If
    End Function
    Friend Shared Function GetFraction(ByVal Num As Double) As MixedFraction(Of Double)

        If Num = 0.0# Then
            GetFraction = New MixedFraction(Of Double) With {.None = True}
        Else
            Dim WholeNumber As Integer
            Dim DecimalNumber As Double
            Dim Numerator As Double
            Dim Denomenator As Double
            Dim a, b, t As Double

            WholeNumber = Fix(Num)
            DecimalNumber = Num - Fix(Num)
            Numerator = DecimalNumber * 10 ^ (Len(CStr(DecimalNumber)) - 2)
            Denomenator = 10 ^ (Len(CStr(DecimalNumber)) - 2)
            If Numerator = 0 Then
                GetFraction = New MixedFraction(Of Double) With {.WholeNumber = WholeNumber}
            Else
                a = Numerator
                b = Denomenator
                t = 0

                While b <> 0
                    t = b
                    b = a Mod b
                    a = t
                End While
                If WholeNumber = 0 Then
                    GetFraction = New MixedFraction(Of Double) With {.Numerator = Numerator / a,
                                                                   .Denominator = Denomenator / a}
                Else
                    GetFraction = New MixedFraction(Of Double) With {.WholeNumber = WholeNumber,
                                                                   .Numerator = Numerator / a,
                                                                   .Denominator = Denomenator / a}
                End If
            End If
        End If
    End Function
    Friend Shared Function GetFraction(ByVal Num As Decimal) As MixedFraction(Of Decimal)

        If Num = 0.0# Then
            GetFraction = New MixedFraction(Of Decimal) With {.None = True}
        Else
            Dim WholeNumber As Integer
            Dim DecimalNumber As Decimal
            Dim Numerator As Decimal
            Dim Denomenator As Decimal
            Dim a, b, t As Decimal

            WholeNumber = Fix(Num)
            DecimalNumber = Num - Fix(Num)
            Numerator = DecimalNumber * 10 ^ (Len(CStr(DecimalNumber)) - 2)
            Denomenator = 10 ^ (Len(CStr(DecimalNumber)) - 2)
            If Numerator = 0 Then
                GetFraction = New MixedFraction(Of Decimal) With {.WholeNumber = WholeNumber}
            Else
                a = Numerator
                b = Denomenator
                t = 0

                While b <> 0
                    t = b
                    b = a Mod b
                    a = t
                End While
                If WholeNumber = 0 Then
                    GetFraction = New MixedFraction(Of Decimal) With {.Numerator = Numerator / a,
                                                                   .Denominator = Denomenator / a}
                Else
                    GetFraction = New MixedFraction(Of Decimal) With {.WholeNumber = WholeNumber,
                                                                   .Numerator = Numerator / a,
                                                                   .Denominator = Denomenator / a}
                End If
            End If
        End If
    End Function
    Public Shared Function Float2Fraction(Float As Double) As Ratio
        'Of T As {IComparable, IFormattable, IComparable(Of T), IEquatable(Of T)})
        Dim df As Double
        Dim lUpperPart As BigInteger = 1
        Dim lLowerPart As BigInteger = 1

        df = lUpperPart / lLowerPart
        While (df <> Float)
            If (df < Float) Then
                lUpperPart = lUpperPart + 1
            Else
                lLowerPart = lLowerPart + 1
                lUpperPart = Float * lLowerPart
            End If
            df = lUpperPart / lLowerPart
        End While
        Return New Ratio(lUpperPart, lLowerPart)
    End Function
    ' primitive operator
    Public Shared Function Add(a As Single, b As Single) As Single
        Return a + b
    End Function
    ' operator defined by the Type
    Public Shared Function Add(a As Decimal, b As Decimal) As Decimal
        Return a + b
    End Function
    ' lifted operator (defined by the T in Nullable<T>)
    Public Shared Function Add(a As Decimal?, b As Decimal?) As Decimal?
        Return a + b
    End Function
    Private Shared Function Add(Of T)(a As T, b As T) As T
        'TODO: re-use delegate!
        ' declare the parameters
        Dim paramA As ParameterExpression = Expression.Parameter(GetType(T), "a"),
            paramB As ParameterExpression = Expression.Parameter(GetType(T), "b")
        ' add the parameters together
        Dim body As BinaryExpression = Expression.Add(paramA, paramB)
        ' compile it
        Dim add__1 As Func(Of T, T, T) = Expression.Lambda(Of Func(Of T, T, T))(body, paramA, paramB).Compile()
        ' call it
        Return add__1(a, b)
    End Function
    Public Overrides Function ToString() As String
        Return Numerator.ToString & "/"c & Denominator.ToString
    End Function
    Public Shared Sub ThrowStackOverflow()
        ThrowStackOverflow()
    End Sub
End Class
