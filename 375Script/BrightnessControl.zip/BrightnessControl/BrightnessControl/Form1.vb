﻿Imports System.Collections
Imports System.Drawing
Imports System.Runtime.InteropServices
Imports System.Windows.Forms
Public Class Form1

    <DllImport("user32.dll")> _
    Public Shared Function GetDC(ByVal hWnd As IntPtr) As IntPtr
    End Function

    <DllImport("gdi32.dll")> _
    Public Shared Function GetDeviceGammaRamp(ByVal hDC As IntPtr, ByRef lpRamp As RAMP) As Boolean
    End Function

    <DllImport("gdi32.dll")> _
    Public Shared Function SetDeviceGammaRamp(ByVal hDC As IntPtr, ByRef lpRamp As RAMP) As Boolean
    End Function

    <StructLayout(LayoutKind.Sequential, CharSet:=CharSet.Ansi)> _
    Public Structure RAMP
        <MarshalAs(UnmanagedType.ByValArray, SizeConst:=256)> _
        Public Red As UInt16()
        <MarshalAs(UnmanagedType.ByValArray, SizeConst:=256)> _
        Public Green As UInt16()
        <MarshalAs(UnmanagedType.ByValArray, SizeConst:=256)> _
        Public Blue As UInt16()
    End Structure

    Public Shared Sub SetGamma(ByVal gamma As Integer)
        If gamma <= 256 AndAlso gamma >= 1 Then
            Dim ramp As New RAMP()
            ramp.Red = New UShort(255) {}
            ramp.Green = New UShort(255) {}
            ramp.Blue = New UShort(255) {}
            For i As Integer = 1 To 255
                Dim iArrayValue As Integer = i * (gamma + 128)

                If iArrayValue > 65535 Then
                    iArrayValue = 65535
                End If
                ramp.Red(i) = InlineAssignHelper(ramp.Blue(i), InlineAssignHelper(ramp.Green(i), CUShort(iArrayValue)))
            Next
            SetDeviceGammaRamp(GetDC(IntPtr.Zero), ramp)
        End If
    End Sub

    Public Shared Sub Main(ByVal args As String())
        Dim ent As String = ""
        Dim g As Integer = 0
        While ent <> "EXIT"
            Console.WriteLine("Enter new Gamma (or 'EXIT' to quit):")
            ent = Console.ReadLine()
            Try
                g = Integer.Parse(ent)
                SetGamma(g)
                'Here only to catch errors where input is not a number (EXIT, for example, is a string)        
            Catch
            End Try
        End While
    End Sub
    Private Shared Function InlineAssignHelper(Of T)(ByRef target As T, ByVal value As T) As T
        target = value
        Return value
    End Function

    Private Sub TrackBar1_Scroll(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TrackBar1.Scroll
        SetGamma(TrackBar1.Value)
        Label1.Text = TrackBar1.Value
    End Sub

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim ramp As New RAMP()
        ramp.Red = New UShort(255) {}
        ramp.Green = New UShort(255) {}
        ramp.Blue = New UShort(255) {}
        GetDeviceGammaRamp(GetDC(IntPtr.Zero), ramp)
        Label1.Text = ramp.Red(0)
        For i As Integer = 1 To 255
            Dim iArrayValue As Integer ' = i * (gamma + 128)

            If iArrayValue > 65535 Then
                iArrayValue = 65535
            End If
            ramp.Red(i) = InlineAssignHelper(ramp.Blue(i), InlineAssignHelper(ramp.Green(i), CUShort(iArrayValue)))
        Next

    End Sub
End Class
