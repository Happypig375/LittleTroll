﻿Imports System.Net.Sockets
Imports System.Console

Module Module1

    Sub Main()
        Write("Enter host to check: ")
        Dim Host As String = ReadLine()
        Write("Timeout (defaults to 1) in milliseconds: ")
        Dim Timeout As Integer = Parse(ReadLine(), 1)
        Write("Starting port (defaults to 1, 0 < Value < 65536): ")
        Dim Start As UShort = Parse(ReadLine(), 1US, False)
        Write("Ending port (defaults to 65535, 0 < Value < 65536): ")
        Dim [End] As UShort = Parse(ReadLine(), 65535US, False)
        WriteLine()
        WriteLine("Avaliable ports: ")
        WriteLine()
        For i As UShort = If(Start < [End], Start, [End]) To If(Start < [End], [End], Start)
            Using Client As New TcpClient()
                ClearLastLine()
                WriteLine("Currently checking port " & i)
                Dim Result As IAsyncResult = Client.BeginConnect(Host, i, Nothing, Nothing)
                Dim Success As Boolean = Result.AsyncWaitHandle.WaitOne(TimeSpan.FromMilliseconds(Timeout))
                If Not Client.Connected Then Continue For
                ' we have connected
                ClearLastLine()
                WriteLine("Port " & i)
                WriteLine()
                Client.EndConnect(Result)
            End Using
        Next i
        ClearLastLine()
        WriteLine()
        WriteLine("Finished checking ports " & Start & " to " & [End] & " for " & Host)
        Write("Press any key to continue...")
        ReadKey()
    End Sub

    Function Parse(S As String, [Default] As Integer, Optional Zero As Boolean = True) As Integer
        Parse = 0
        If Not Integer.TryParse(S, Parse) Then Parse = [Default]
        Return If(Parse = 0 And Not Zero, [Default], Parse)
    End Function
    Function Parse(S As String, [Default] As UShort, Optional Zero As Boolean = True) As UShort
        Parse = 0
        If Not UShort.TryParse(S, Parse) Then Parse = [Default]
        Return If(Parse = 0 And Not Zero, [Default], Parse)
    End Function
    Public Sub ClearLastLine()
        SetCursorPosition(0, Console.CursorTop - 1)
        Write(New String(" "c, Console.BufferWidth))
        SetCursorPosition(0, Console.CursorTop - 1)
    End Sub
End Module
