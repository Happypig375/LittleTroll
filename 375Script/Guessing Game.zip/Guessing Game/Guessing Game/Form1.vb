﻿Public Class Form1
    Dim Number, Count As Integer
    Private Sub Button1_Click(sender As System.Object, e As System.EventArgs) Handles Button1.Click
        Select Case CInt(TextBox1.Value)
            Case Is < TextBox1.Minimum, Is > TextBox1.Maximum
                MsgBox("Number out of range!")
                Return
            Case Is < Number
                MsgBox("Too small!")
                Label4.Text = TextBox1.Text + 1
                TextBox1.Minimum = Label4.Text
            Case Is > Number
                MsgBox("Too large!")
                Label5.Text = TextBox1.Text - 1
                TextBox1.Maximum = Label5.Text
            Case Else
                MsgBox("Well done! You Win!!")
                Button1.Enabled = False
        End Select
        If Count < 10 Then
            Count += 1
            Label3.Text = "Count: " & Count
        Else
            MsgBox("YOU LOSE")
            Button2_Click(sender, e)
        End If
    End Sub

    Private Sub Form1_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        Button2_Click(sender, e)
    End Sub

    Private Sub Button2_Click(sender As System.Object, e As System.EventArgs) Handles Button2.Click
        TextBox1.Minimum = InputBox("Enter smallest number:", "Enter range", 1)
        TextBox1.Maximum = InputBox("Enter largest number:", "Enter range", 100)
        Count = 0
        Label3.Text = "Count: " & Count
        Number = New Random().Next(TextBox1.Minimum, TextBox1.Maximum)
        Label4.Text = TextBox1.Minimum
        Label5.Text = TextBox1.Maximum
        Button1.Enabled = True
    End Sub
End Class
