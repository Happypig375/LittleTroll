﻿Namespace My

    ' The following events are available for MyApplication:
    ' 
    ' Startup: Raised when the application starts, before the startup form is created.
    ' Shutdown: Raised after all application forms are closed.  This event is not raised if the application terminates abnormally.
    ' UnhandledException: Raised if the application encounters an unhandled exception.
    ' StartupNextInstance: Raised when launching a single-instance application and the application is already active. 
    ' NetworkAvailabilityChanged: Raised when the network connection is connected or disconnected.
    Partial Friend Class MyApplication

        Private Sub MyApplication_Startup(ByVal sender As Object,
                                          ByVal e As Microsoft.VisualBasic.ApplicationServices.StartupEventArgs) Handles Me.Startup
            If e.CommandLine.Count <> 0 Then
#If False Then
                Dim File As String = IO.Path.Combine(My.Computer.FileSystem.SpecialDirectories.Temp,
                                                     IO.Path.GetFileName(e.CommandLine(0)))
                My.Computer.FileSystem.WriteAllBytes(File, {0, 1, 2, 3}, False)
                Process.Start("C:\Program Files\Microsoft Office\Office14\POWERPNT.exe", File)
#Else
                MsgBox("PowerPoint cannot open the file represented by " & e.CommandLine(0) & "."c & vbCrLf & vbCrLf &
                       "The file might have become corrupted. If you have a backup copy of the file, use it." &
                       " It is not possible to repair a corrupted file.", MessageBoxIcon.Exclamation, "Microsoft PowerPoint")
#End If
                e.Cancel = True
            End If
        End Sub
    End Class


End Namespace

