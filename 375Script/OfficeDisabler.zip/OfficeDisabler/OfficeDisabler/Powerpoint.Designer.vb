﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Powerpoint
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Switch = New System.Windows.Forms.CheckBox()
        Me.SuspendLayout()
        '
        'Switch
        '
        Me.Switch.Appearance = System.Windows.Forms.Appearance.Button
        Me.Switch.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Switch.Location = New System.Drawing.Point(0, 0)
        Me.Switch.Name = "Switch"
        Me.Switch.Size = New System.Drawing.Size(238, 26)
        Me.Switch.TabIndex = 0
        Me.Switch.Text = "On"
        Me.Switch.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.Switch.UseVisualStyleBackColor = True
        '
        'Powerpoint
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(238, 26)
        Me.Controls.Add(Me.Switch)
        Me.Name = "Powerpoint"
        Me.Text = "PowerPointDisabler"
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Switch As System.Windows.Forms.CheckBox

End Class
