﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class GUI
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Brightness = New System.Windows.Forms.TrackBar()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.ColorSel = New System.Windows.Forms.ColorDialog()
        Me.ColorButton = New System.Windows.Forms.Button()
        Me.ColorDisplay = New System.Windows.Forms.PictureBox()
        Me.ColorClr = New System.Windows.Forms.Button()
        Me.ColorRbw = New System.Windows.Forms.Button()
        Me.ColorRdm = New System.Windows.Forms.Button()
        CType(Me.Brightness, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ColorDisplay, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Brightness
        '
        Me.Brightness.LargeChange = 25
        Me.Brightness.Location = New System.Drawing.Point(37, 12)
        Me.Brightness.Maximum = 256
        Me.Brightness.Minimum = 1
        Me.Brightness.Name = "Brightness"
        Me.Brightness.Size = New System.Drawing.Size(506, 45)
        Me.Brightness.TabIndex = 0
        Me.Brightness.Value = 1
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(12, 21)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(25, 13)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "255"
        '
        'ColorButton
        '
        Me.ColorButton.Location = New System.Drawing.Point(43, 63)
        Me.ColorButton.Name = "ColorButton"
        Me.ColorButton.Size = New System.Drawing.Size(75, 23)
        Me.ColorButton.TabIndex = 2
        Me.ColorButton.Text = "Filter Colour"
        Me.ColorButton.UseVisualStyleBackColor = True
        '
        'ColorDisplay
        '
        Me.ColorDisplay.Location = New System.Drawing.Point(13, 63)
        Me.ColorDisplay.Name = "ColorDisplay"
        Me.ColorDisplay.Size = New System.Drawing.Size(24, 24)
        Me.ColorDisplay.TabIndex = 3
        Me.ColorDisplay.TabStop = False
        '
        'ColorClr
        '
        Me.ColorClr.Location = New System.Drawing.Point(124, 63)
        Me.ColorClr.Name = "ColorClr"
        Me.ColorClr.Size = New System.Drawing.Size(75, 23)
        Me.ColorClr.TabIndex = 4
        Me.ColorClr.Text = "Clear Filter"
        Me.ColorClr.UseVisualStyleBackColor = True
        '
        'ColorRbw
        '
        Me.ColorRbw.Location = New System.Drawing.Point(205, 63)
        Me.ColorRbw.Name = "ColorRbw"
        Me.ColorRbw.Size = New System.Drawing.Size(89, 23)
        Me.ColorRbw.TabIndex = 5
        Me.ColorRbw.Text = "Rainbow Filter"
        Me.ColorRbw.UseVisualStyleBackColor = True
        '
        'ColorRdm
        '
        Me.ColorRdm.Location = New System.Drawing.Point(301, 64)
        Me.ColorRdm.Name = "ColorRdm"
        Me.ColorRdm.Size = New System.Drawing.Size(89, 23)
        Me.ColorRdm.TabIndex = 6
        Me.ColorRdm.Text = "Random Filter"
        Me.ColorRdm.UseVisualStyleBackColor = True
        '
        'GUI
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(555, 102)
        Me.Controls.Add(Me.ColorRdm)
        Me.Controls.Add(Me.ColorRbw)
        Me.Controls.Add(Me.ColorClr)
        Me.Controls.Add(Me.ColorDisplay)
        Me.Controls.Add(Me.ColorButton)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Brightness)
        Me.Name = "GUI"
        Me.Text = "BrightnessControl"
        Me.TopMost = True
        CType(Me.Brightness, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ColorDisplay, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Brightness As System.Windows.Forms.TrackBar
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents ColorSel As System.Windows.Forms.ColorDialog
    Friend WithEvents ColorButton As System.Windows.Forms.Button
    Friend WithEvents ColorDisplay As System.Windows.Forms.PictureBox
    Friend WithEvents ColorClr As System.Windows.Forms.Button
    Friend WithEvents ColorRbw As System.Windows.Forms.Button
    Friend WithEvents ColorRdm As System.Windows.Forms.Button

End Class
