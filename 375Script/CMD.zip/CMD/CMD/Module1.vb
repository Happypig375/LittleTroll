﻿Option Compare Text

Imports System.Runtime.InteropServices
Imports System.Text
Module Module1
    Const Win32 As String = "C:\Windows\System32"
    Dim InnerProcess As New Process
    Sub Main()
        Dim Environ As String = Environment.GetEnvironmentVariable("Path")
        If Not Environ.Contains(Win32) Then Environment.SetEnvironmentVariable(Environ, Environ & ";"c & Win32)
        Dim CurrentPath As String = "C:\"
        Console.WriteLine("Microsoft Windows [Version " & Environment.OSVersion.Version.ToString & "]"c)
        Console.WriteLine("Copyright (c) 2009 Microsoft Corporation. All rights reserved.")
        Console.WriteLine()
        Do
            Console.Write(CurrentPath & ">"c)
            Dim Line() As String = SplitArgs(Console.ReadLine)
            StartProcess(Line)
        Loop
        'Dim log As New Logging.Log("Test")
        'log.TraceSource.Switch.Level.ToString.Trim.Clone.GetType.EmptyTypes.Single.GetArrayRank.GetHashCode.GetTypeCode.GetType.DefaultBinder.GetHashCode.ToString.TrimStart.TrimEnd.Any.FalseString.ToCharArray.SyncRoot.GetType.DeclaringMethod.Attributes.HasSecurity.ToString.SingleOrDefault.MaxValue.GetTypeCode.GetTypeCode.GetTypeCode.Char.ToString()
    End Sub

    Private Sub StartProcess(Line As String())
        Dim Items As String = Nothing
        For Each Item As String In Line.Skip(1)
            Items &= Item & " "c
        Next
        With InnerProcess
            .StartInfo = New ProcessStartInfo(Line(0), Items)
            .StartInfo.UseShellExecute = False
            Try
                .Start()
                .WaitForExit()
            Catch ex As ComponentModel.Win32Exception When ex.Message = "The system cannot find the file specified"
                Select Case Line(0)
                    Case "echo"
                        Console.WriteLine(Items)
                        Console.WriteLine()
                    Case "exit"
                        End
                    Case Else
                        Console.WriteLine(ex.Message & "."c & vbCrLf)
                End Select
            End Try
        End With
    End Sub
#Region "Exception"
#If False Then
    System.ComponentModel.Win32Exception was unhandled
  ErrorCode=-2147467259
  HResult=-2147467259
  Message=The system cannot find the file specified
  NativeErrorCode=2
  Source=System
  StackTrace:
       at System.Diagnostics.Process.StartWithShellExecuteEx(ProcessStartInfo startInfo)
       at System.Diagnostics.Process.Start()
       at System.Diagnostics.Process.Start(ProcessStartInfo startInfo)
       at System.Diagnostics.Process.Start(String fileName, String arguments)
       at CMD.Module1.Main() in C:\Users\s14110\AppData\Local\Temporary Projects\CMD\Module1.vb:line 20
       at System.AppDomain._nExecuteAssembly(RuntimeAssembly assembly, String[] args)
       at System.AppDomain.ExecuteAssembly(String assemblyFile, Evidence assemblySecurity, String[] args)
       at Microsoft.VisualStudio.HostingProcess.HostProc.RunUsersAssembly()
       at System.Threading.ThreadHelper.ThreadStart_Context(Object state)
       at System.Threading.ExecutionContext.RunInternal(ExecutionContext executionContext, ContextCallback callback, Object state, Boolean preserveSyncCtx)
       at System.Threading.ExecutionContext.Run(ExecutionContext executionContext, ContextCallback callback, Object state, Boolean preserveSyncCtx)
       at System.Threading.ExecutionContext.Run(ExecutionContext executionContext, ContextCallback callback, Object state)
       at System.Threading.ThreadHelper.ThreadStart()
  InnerException: 

#End If
#End Region

    ' The previous examples on this page used incorrect
    ' pointer logic and were removed.

    Public Function SplitArgs(unsplitArgumentLine As String) As String()
        Dim numberOfArgs As Integer
        Dim ptrToSplitArgs As IntPtr
        Dim splitArgs__1 As String()

        ptrToSplitArgs = CommandLineToArgvW(unsplitArgumentLine, numberOfArgs)

        ' CommandLineToArgvW returns NULL upon failure.
        If ptrToSplitArgs = IntPtr.Zero Then
            Throw New ArgumentException("Unable to split argument.", New ComponentModel.Win32Exception())
        End If

        ' Make sure the memory ptrToSplitArgs to is freed, even upon failure.
        Try
            splitArgs__1 = New String(numberOfArgs - 1) {}

            ' ptrToSplitArgs is an array of pointers to null terminated Unicode strings.
            ' Copy each of these strings into our split argument array.
            For i As Integer = 0 To numberOfArgs - 1
                splitArgs__1(i) = Marshal.PtrToStringUni(Marshal.ReadIntPtr(ptrToSplitArgs, i * IntPtr.Size))
            Next

            Return splitArgs__1
        Finally
            ' Free memory obtained by CommandLineToArgW.
            LocalFree(ptrToSplitArgs)
        End Try
    End Function

    <DllImport("shell32.dll", SetLastError:=True)> _
    Private Function CommandLineToArgvW(<MarshalAs(UnmanagedType.LPWStr)> lpCmdLine As String, ByRef pNumArgs As Integer) As IntPtr
    End Function

    <DllImport("kernel32.dll")> _
    Private Function LocalFree(hMem As IntPtr) As IntPtr
    End Function
End Module