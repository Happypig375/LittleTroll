﻿
Public Class _375Control
    Public Shared Function GetLocalIPAddress() As IPAddress
        If System.Net.NetworkInformation.NetworkInterface.GetIsNetworkAvailable Then _
            Throw New WebException("Network is not avaliable!")
        Dim Host = Dns.GetHostEntry(Dns.GetHostName())
        For Each IP As IPAddress In Host.AddressList
            If IP.AddressFamily = AddressFamily.InterNetwork Then
                Return IP
            End If
        Next
        Throw New KeyNotFoundException("Local IP Address Not Found!")
    End Function

    Shared Sub Connect(ByVal server As String, ByVal message As String, Optional ByVal Port As Int32 = 37535)
        Try
            ' Create a TcpClient.
            ' Note, for this client to work you need to have a TcpServer 
            ' connected to the same address as specified by the server, port
            ' combination.
            Using client As New TcpClient(server, Port)
                Dns.GetHostName()
                ' Translate the passed message into ASCII and store it as a Byte array.
                Dim data As Byte() = System.Text.Encoding.ASCII.GetBytes(message)

                ' Get a client stream for reading and writing.
                '  Stream stream = client.GetStream();
                Using stream As NetworkStream = client.GetStream()

                    ' Send the message to the connected TcpServer. 
                    stream.Write(data, 0, data.Length)

                    Console.WriteLine("Sent: {0}", message)

                    ' Receive the TcpServer.response.
                    ' Buffer to store the response bytes.
                    data = New Byte(256) {}

                    ' String to store the response ASCII representation.
                    Dim responseData As String = String.Empty

                    ' Read the first batch of the TcpServer response bytes.
                    Dim bytes As Int32 = stream.Read(data, 0, data.Length)
                    responseData = System.Text.Encoding.ASCII.GetString(data, 0, bytes)
                    Console.WriteLine("Received: {0}", responseData)

                    ' Close everything.
                End Using
            End Using
        Catch e As ArgumentNullException
            Console.WriteLine("ArgumentNullException: {0}", e)
        Catch e As SocketException
            Console.WriteLine("SocketException: {0}", e)
        End Try

        Console.WriteLine(ControlChars.Cr + " Press Enter to continue...")
        Console.Read()
    End Sub 'Connect

    Public Shared Sub Listen(Optional ByVal Port As Int32 = 37535)

        Dim server As TcpListener
        server = Nothing
        Try
            ' Set the TcpListener on port 13000.
            Dim localAddr As IPAddress = GetLocalIPAddress() 'IPAddress.Parse("127.0.0.1")

            server = New TcpListener(localAddr, Port)

            ' Start listening for client requests.
            server.Start()

            ' Buffer for reading data
            Dim bytes(1024) As Byte
            Dim data As String = Nothing

            ' Enter the listening loop.
            While True
                Console.Write("Waiting for a connection... ")

                ' Perform a blocking call to accept requests.
                ' You could also user server.AcceptSocket() here.
                Using client As TcpClient = server.AcceptTcpClient()
                    Console.WriteLine("Connected!")

                    data = Nothing

                    ' Get a stream object for reading and writing
                    Dim stream As NetworkStream = client.GetStream()

                    Dim i As Int32

                    ' Loop to receive all the data sent by the client.
                    i = stream.Read(bytes, 0, bytes.Length)
                    While (i <> 0)
                        ' Translate data bytes to a ASCII string.
                        data = System.Text.Encoding.ASCII.GetString(bytes, 0, i)
                        Console.WriteLine("Received: {0}", data)

                        ' Process the data sent by the client.
                        data = data.ToUpper()
                        Dim msg As Byte() = System.Text.Encoding.ASCII.GetBytes(data)

                        ' Send back a response.
                        stream.Write(msg, 0, msg.Length)
                        Console.WriteLine("Sent: {0}", data)

                        i = stream.Read(bytes, 0, bytes.Length)

                    End While

                    ' Shutdown and end connection
                End Using
            End While
        Catch e As SocketException
            Console.WriteLine("SocketException: {0}", e)
        Finally
            server.Stop()
        End Try

        Console.WriteLine(ControlChars.Cr + "Hit enter to continue....")
        Console.Read()
    End Sub 'Main

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click

    End Sub
End Class
